<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$posts = get_posts();
$pageTitle = "Головна";
require 'includes/header.php'; 
?>

<main>
    <?php if (count($posts) > 0): ?>
        <?php foreach ($posts as $post): ?>
            <article>
                <div class="meta-top">
                    <a href="post.php?id=<?= $post['id'] ?>">Читати далі</a>
                    
                    <?php if (is_admin()): ?>
                        <span>•</span>
                        <a href="post-editor.php?id=<?= $post['id'] ?>">Ред.</a>
                    <?php endif; ?>
                </div>

                <h2>
                    <a href="post.php?id=<?= $post['id'] ?>">
                        <?= htmlspecialchars($post['title']) ?>
                    </a>
                </h2>
                
                <div class="content">
                    <?= nl2br(htmlspecialchars(excerpt($post['content'], 300))) ?>
                </div>
                
                <div class="meta-bottom">
                    <?= estimate_reading_time($post['content']) ?> хв читання
                </div>
            </article>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align: center; padding: 50px 0; color: #999;">
            <p>Ще немає жодного запису.</p>
            <?php if (is_admin()): ?>
                <a href="post-editor.php" class="btn btn-primary">Створити перший пост</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</main>

<?php require 'includes/footer.php'; ?>